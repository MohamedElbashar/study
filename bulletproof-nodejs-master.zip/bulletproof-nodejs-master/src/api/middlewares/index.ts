import attachCurrentUser from './attachCurrentUser';
import isAuth from './isAuth';

export default {
  attachCurrentUser,
  isAuth,
};
